
Author: Justin Nichols
Class: CSC337 (Web Development)
Purpose: This web project contains a form to sign up for a RuneScape account.
         The purpose of this exercise is to practice using forms, as well as
         to get some more practice with HTML and CSS in general.

